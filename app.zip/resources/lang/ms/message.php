<?php
return [
    'welcome' => 'Selamat datang ke laman web kami!',
    'login' => 'Log Masuk',
    'logout' => 'Log Keluar',
];
